package com.codenameone;

class MyLibrary {
    public void helloWorld() {
        System.out.println("Hello World");
    }
}